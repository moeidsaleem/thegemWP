    jQuery.ajax({
        url : ajaxurl,
        type : "POST",
        data : {
            "action" : "coundown_ajax_handler",
        }
    });

    jQuery('.countdown-container .item-count').text('0');